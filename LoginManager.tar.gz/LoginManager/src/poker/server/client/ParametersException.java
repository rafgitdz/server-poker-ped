package poker.server.client;

public class ParametersException extends RuntimeException {

	private static final long serialVersionUID = -5618833794473171082L;

	public ParametersException(String message) {
		super(message);
	}
}
