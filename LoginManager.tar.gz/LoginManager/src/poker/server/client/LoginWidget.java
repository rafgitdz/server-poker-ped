package poker.server.client;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class LoginWidget extends Composite {

	private static final String GWT_BUTTON_LOGIN = "gwt-Button-Login";
	private static final String GWT_TEXT_AREA_LOGIN = "gwt-TextArea-Login";
	private static final String BLANK = "";
	TextArea textAreaKey;
	Button btnOk;
	Label resulSecretKeyLabel;
	Label resultConsumerKeyLabel;

	public LoginWidget() {

		VerticalPanel verticalPanel = new VerticalPanel();
		verticalPanel.setBorderWidth(2);
		verticalPanel
				.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
		initWidget(verticalPanel);
		verticalPanel.setSize("580px", "344px");

		Label lblSignIntoYour = new Label("Describe your application");
		lblSignIntoYour.setStyleName("gwt-CheckBox-Login");
		verticalPanel.add(lblSignIntoYour);
		verticalPanel.setCellVerticalAlignment(lblSignIntoYour,
				HasVerticalAlignment.ALIGN_MIDDLE);
		lblSignIntoYour.setHeight("21px");

		FlexTable flexTable = new FlexTable();
		verticalPanel.add(flexTable);
		verticalPanel.setCellHorizontalAlignment(flexTable,
				HasHorizontalAlignment.ALIGN_CENTER);
		flexTable.setSize("429px", "38px");

		Label lblUsername = new Label("Application:");
		lblUsername.setStyleName("gwt-Label-loginBis");
		flexTable.setWidget(0, 0, lblUsername);
		lblUsername.setWidth("175px");
		flexTable.getCellFormatter().setStyleName(0, 0, "gwt-Label-Login");

		final TextBox textBoxAppli = new TextBox();
		textBoxAppli.setStyleName(GWT_TEXT_AREA_LOGIN);

		flexTable.setWidget(0, 1, textBoxAppli);
		textBoxAppli.setWidth("230px");

		Label lblNewLabel = new Label("Description:");
		lblNewLabel.setStyleName("gwt-Label-loginBis");
		flexTable.setWidget(1, 0, lblNewLabel);
		flexTable.getCellFormatter().setStyleName(1, 0, "gwt-Label-Login");

		final TextArea textArea = new TextArea();
		textArea.setCharacterWidth(50);
		textArea.setStyleName(GWT_TEXT_AREA_LOGIN);
		flexTable.setWidget(1, 1, textArea);
		flexTable.getCellFormatter().setStyleName(1, 1, "gwt-Label-Login");
		textArea.setSize("230px", "116px");

		final CheckBox chckbxCondition = new CheckBox("I agree the conditions");
		flexTable.setWidget(2, 1, chckbxCondition);
		chckbxCondition.setWidth("232px");
		flexTable.getCellFormatter().setStyleName(2, 1, "gwt-CheckBox-Login");
		flexTable.getCellFormatter().setHorizontalAlignment(1, 0,
				HasHorizontalAlignment.ALIGN_RIGHT);
		flexTable.getCellFormatter().setHorizontalAlignment(0, 0,
				HasHorizontalAlignment.ALIGN_RIGHT);

		textAreaKey = new TextArea();

		btnOk = new Button("OK");
		btnOk.setStyleName(GWT_BUTTON_LOGIN);
		btnOk.setVisible(false);

		Button btnSubmit = new Button("Submit");
		btnSubmit.setStyleName(GWT_BUTTON_LOGIN);

		final LoginWidget loginWidget = this;

		btnSubmit.addClickHandler(new ClickHandler() {

			@SuppressWarnings("deprecation")
			public void onClick(ClickEvent event) {

				if (textBoxAppli.getText().length() == 0
						|| textArea.getText().length() == 0) {
					Window.alert("Application or Description is empty!");
				} else {
					if (chckbxCondition.isChecked() == false) {
						Window.alert("Agree the condition!");
					} else {
						RequestHandler requestHandler = new RequestHandler();
						requestHandler.getConsumerKey(loginWidget,
								textBoxAppli.getText());
					}
				}
			}

		});

		flexTable.setWidget(3, 0, btnSubmit);
		btnSubmit.setSize("100px", "25");
		flexTable.getCellFormatter().setStyleName(3, 0, GWT_BUTTON_LOGIN);
		flexTable.getCellFormatter().setHorizontalAlignment(3, 0,
				HasHorizontalAlignment.ALIGN_RIGHT);

		Button btnCancel = new Button("Cancel");
		btnCancel.setStyleName(GWT_BUTTON_LOGIN);
		btnCancel.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				textBoxAppli.setText(BLANK);
				textArea.setText(BLANK);
			}
		});
		flexTable.setWidget(3, 1, btnCancel);
		btnCancel.setSize("100px", "25");
		flexTable.getCellFormatter().setStyleName(3, 1, GWT_BUTTON_LOGIN);
		flexTable.getCellFormatter().setVerticalAlignment(1, 0,
				HasVerticalAlignment.ALIGN_TOP);

		btnOk.addClickHandler(new ClickHandler() {
			@SuppressWarnings("deprecation")
			public void onClick(ClickEvent event) {

				textBoxAppli.setText(BLANK);
				textArea.setText(BLANK);
				textAreaKey.setText(BLANK);
				textAreaKey.setVisible(false);
				chckbxCondition.setChecked(false);
				btnOk.setVisible(false);
			}
		});

		textAreaKey.setStyleName(GWT_TEXT_AREA_LOGIN);
		textAreaKey.setVisible(false);
		flexTable.setWidget(4, 1, textAreaKey);
		textAreaKey.setWidth("500px");
		// flexTable.setWidget(5, 1, btnOk);
		flexTable.getCellFormatter().setStyleName(5, 1, GWT_BUTTON_LOGIN);
		btnOk.setSize("100px", "25");
		flexTable.getCellFormatter().setHorizontalAlignment(4, 1,
				HasHorizontalAlignment.ALIGN_LEFT);

		VerticalPanel resultVerticalPanel = new VerticalPanel();

		HorizontalPanel consumerHorizontalPanel = new HorizontalPanel();
		HorizontalPanel secretHorizontalPanel = new HorizontalPanel();

		Label consumerLabel = new Label("Consumer key : ");
		resultConsumerKeyLabel = new Label();
		consumerHorizontalPanel.add(consumerLabel);

		consumerHorizontalPanel.setCellHorizontalAlignment(consumerLabel,
				HasHorizontalAlignment.ALIGN_RIGHT);

		consumerHorizontalPanel.add(resultConsumerKeyLabel);

		Label secretTextLabel = new Label("Secret key : ");

		resulSecretKeyLabel = new Label();
		secretHorizontalPanel.add(secretTextLabel);

		secretHorizontalPanel.setCellHorizontalAlignment(secretTextLabel,
				HasHorizontalAlignment.ALIGN_RIGHT);

		secretHorizontalPanel.add(resulSecretKeyLabel);

		resultVerticalPanel.add(consumerHorizontalPanel);
		resultVerticalPanel.add(secretHorizontalPanel);
		resultVerticalPanel.add(btnOk);
		
		//resultVerticalPanel.setCellVerticalAlignment(btnOk, HasVerticalAlignment.)

		verticalPanel.add(resultVerticalPanel);

	}

	public void updateResultConsumerKey(String consumerKey, String secret) {

		String text = "Consumer key : " + consumerKey + "\n" + "Secret : "
				+ secret;

		textAreaKey.setVisible(true);
		textAreaKey.setText(text);

		resultConsumerKeyLabel.setText(consumerKey);
		resulSecretKeyLabel.setText(secret);
		btnOk.setVisible(true);
	}

}
